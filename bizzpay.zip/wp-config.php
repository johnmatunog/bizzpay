<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', '' );

/** MySQL database username */
define( 'DB_USER', '' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', '' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'i5lqzpcjdlhecmz2qk1x7lhfzqoufqpubutb2tedy5kf4csbyp5vu6rhc6p4pz8h' );
define( 'SECURE_AUTH_KEY',  'nf6ht36bz2w0gcssf11hvc1dzacsvsoegtb43rqips0njw5alk4o1nfmmxkw0415' );
define( 'LOGGED_IN_KEY',    'j8yd05ahok2bnd9dd1ecggvsjzmlkxuw9xfphq6fknue2uiglxzpquam0lbxtats' );
define( 'NONCE_KEY',        '3w6srapw1codun4lmyobx9c9guxzkd4tmm8dchyo2thpecnfqoceho8cze8b3pwc' );
define( 'AUTH_SALT',        'phdwav5iz1oefsfvr75b99lacggmeiulz2fi4ccv1l0lunifaax7o8oc1tnkheyy' );
define( 'SECURE_AUTH_SALT', 'paa1elsr5yxhxlgx1z94ynwep409zb6mmjbarrdcrdhet7d5xiclx2yt6bysbvle' );
define( 'LOGGED_IN_SALT',   'xsmjnx2ijwp8d5i3ewuukme6xesmgzegkh3tbwvphnbqfqoclzhbbup1tkzr4vb9' );
define( 'NONCE_SALT',       'jznkfbedwryszlikamyteetccr3imvrxq1npvrmoupbnbibse6u6bwoug9hz347m' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp0t_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
